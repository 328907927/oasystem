package com.hugo.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hugo.biz.MenuBiz;
import com.hugo.biz.impl.MenuBizImpl;
import com.hugo.entity.Menu;

import comhugo.util.JSONResult;
import comhugo.util.StaticData;
import net.sf.json.JSONObject;

@WebServlet("/selectMenuByRoleNoServlet")
public class SelectMenuByRoleNoServlet extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		int roleNo=Integer.parseInt(request.getParameter("roleNo"));
		MenuBiz  biz = new MenuBizImpl();
		try {
			List<Menu> list =biz.selectMenuByRoleNo(roleNo);
			//封装数据
			JSONResult jsonResult = new JSONResult();
			jsonResult.setList(list);
			jsonResult.setStatus(StaticData.SUCCESS);
			//响应数据
			JSONObject json = JSONObject.fromObject(jsonResult);
			response.setContentType("text/html;charset=utf-8");
			response.getWriter().print(json.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
	 }

}

