package com.hugo.servlet;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hugo.biz.EmpBiz;
import com.hugo.biz.impl.EmpBizImpl;

import comhugo.util.JSONResult;
import comhugo.util.Page;
import comhugo.util.StaticData;
import net.sf.json.JSONObject;

@WebServlet("/selectEmpByPage")
public class SelectEmpByPage extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
	int pageIndex =Integer.parseInt(request.getParameter("pageIndex"));
	int num=Integer.parseInt(request.getParameter("num"));
	int deptNo =Integer.parseInt(request.getParameter("deptNo"));
	String realName = request.getParameter("realName");
	//执行查询
	EmpBiz biz = new EmpBizImpl();
	try {
		//查询分页员工的数据
		List<Map> list = biz.selectPage(pageIndex, num, deptNo, realName);
		//查询满足条件的员工数据总行数
		int dataCount =biz.seletDataCount(deptNo, realName);
		Page page = new Page();
		page.setPageIndex(pageIndex);
		page.setDataCount(dataCount);
		//计算总页数
		int PageCount=dataCount%num==0?dataCount/num:dataCount/num+1;
		page.setPageCount(PageCount);
		//查询数据总条数
		//封装分页查询数据
		JSONResult jsonResult = new JSONResult();
		jsonResult.setList(list);
		jsonResult.setPage(page);
		jsonResult.setStatus(StaticData.SUCCESS);
		//响应数据
		JSONObject json =JSONObject.fromObject(jsonResult);
		response.setContentType("text/html;charset=utf-8");
		response.getWriter().print(json.toString());
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	
	}

}
