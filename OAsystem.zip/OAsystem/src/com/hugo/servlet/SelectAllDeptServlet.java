package com.hugo.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hugo.biz.DeptBiz;
import com.hugo.biz.impl.DeptBizImpl;
import com.hugo.entity.Dept;

import comhugo.util.JSONResult;
import comhugo.util.StaticData;
import net.sf.json.JSONObject;

@WebServlet("/selectAllDeptServlet")
public class SelectAllDeptServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		DeptBiz deptBiz = new DeptBizImpl();
		try {
			List<Dept> list=deptBiz.selectAllDept();
			//封装json数据
			JSONResult jsonResult = new JSONResult();
			jsonResult.setLoginStatus(StaticData.LOGIN);
			jsonResult.setStatus(StaticData.SUCCESS);
			jsonResult.setList(list);
			//使用json包提供的方法将对象转为json字符串
			String json=JSONObject.fromObject(jsonResult).toString();
			response.setContentType("text/html;charset=utf-8");
			response.getWriter().print(json);
		} catch (Exception e) {
	
			e.printStackTrace();
		}
	}

}
