package com.hugo.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hugo.biz.DeptBiz;
import com.hugo.biz.impl.DeptBizImpl;

import comhugo.util.JSONResult;
import comhugo.util.StaticData;
import net.sf.json.JSONObject;

@WebServlet("/deleteDeptServlet")
public class DeleteDeptServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		int deptNo =Integer.parseInt(request.getParameter("deptNo"));
		DeptBiz biz = new DeptBizImpl();
		try {
			biz.delete(deptNo);
//			封装JSON数据
			JSONResult jsonResult = new JSONResult();
			jsonResult.setStatus(StaticData.SUCCESS);
			System.out.println(jsonResult.getStatus());
			jsonResult.setMessage(StaticData.DELETE_DEPT_SUCCESS_MESSAGE);
			response.setContentType("text/html;setchar=utf-8");
			String json =JSONObject.fromObject(jsonResult).toString();
			response.getWriter().print(json);
			System.out.println(json);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
