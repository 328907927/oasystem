package com.hugo.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hugo.biz.RoleBiz;
import com.hugo.biz.impl.RoleBizImpl;
import com.hugo.entity.Role;

import comhugo.util.JSONResult;
import comhugo.util.StaticData;
import net.sf.json.JSONObject;
@WebServlet("/selectRoleServlet")
public class SelectRoleServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		RoleBiz biz = new RoleBizImpl();
		try {
			List<Role> role = biz.selectRole();
			//封装数据
			JSONResult jsonResult = new JSONResult();
			jsonResult.setList(role);
			jsonResult.setStatus(StaticData.SUCCESS);
			//响应数据
			JSONObject json = JSONObject.fromObject(jsonResult);
			response.setContentType("text/html;charset=utf-8");
			response.getWriter().print(json.toString());
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
