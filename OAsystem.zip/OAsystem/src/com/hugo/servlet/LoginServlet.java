package com.hugo.servlet;

import java.io.IOException;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hugo.biz.UserBiz;
import com.hugo.biz.impl.UserBizImpl;
import com.hugo.entity.Employee;

import comhugo.util.StaticData;
@WebServlet("/login")
public class LoginServlet extends HttpServlet{
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
//		获取数据并且判断数据的合法性
		String username = request.getParameter("username");
		String password = request.getParameter("password");
//		System.out.println(username);
//		System.out.println(password);
		if(username==null||username.equals("")){
//			用户名数据不合法，响应到登录页面
			request.setAttribute("message",StaticData.USERNAME_NULL);
			request.getRequestDispatcher("login.jsp").forward(request, response);
		}else if(password==null||password.equals("")){
//			密码数据不合法，响应到登录页面
			request.setAttribute("message",StaticData.PASSWORD_NULL);
			request.getRequestDispatcher("login.jsp").forward(request, response);
		}else{
			UserBiz userBiz = new UserBizImpl();
			try {
			Employee emp =userBiz.login(username,password);
			if(emp==null){
//				用户名不正确，响应到登录页面
				request.setAttribute("message",StaticData.USERNAME_OR_PASSWORD_ERROR);
				request.getRequestDispatcher("login.jsp").forward(request, response);
			}else{
				//将返回来的用户信息保存到sesssion里
				request.getSession().setAttribute(StaticData.USER_INFO,emp);
//				生成token令牌
//				使用UUID生成不重复的32位长度的字符串
				String token=UUID.randomUUID().toString().replace("-", "");
				//将token令牌记录到当前登录用户的数据库中
				userBiz.setToken(emp.getEmpNo(), token);
				//使用cookie将token信息保存到浏览器
				//创建cookie
				Cookie cookie=new Cookie("token",token);
				//设置cookie有效时间(单位秒)
				cookie.setMaxAge(7*24*60*60);
				//将cookie响应给浏览器
				response.addCookie(cookie);
				
//				跳转到首页
				response.sendRedirect("index.jsp");
			}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
}
