package com.hugo.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hugo.biz.PrivilegeBiz;
import com.hugo.biz.impl.PrivilegeBizImpl;

import comhugo.util.JSONResult;
import comhugo.util.StaticData;
import net.sf.json.JSONObject;

@WebServlet("/sharePrivilegeServlet")
public class SharePrivilegeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//获取页面传递过来的数据
		String pnos =request.getParameter("pnos");
		String cnos = request.getParameter("cnos");
		int roleNo =Integer.parseInt(request.getParameter("roleNo"));
		PrivilegeBiz biz = new PrivilegeBizImpl();
		try {
			biz.sharPrivilege(roleNo, pnos.split(","), cnos.split(","));
			//封装json数据
			JSONResult jsonResult = new JSONResult();
			jsonResult.setStatus(StaticData.SUCCESS);
			jsonResult.setMessage(StaticData.AUTHORIZATION__SUCCESS_MESSAGE);
			//使用json包提供的方法将对象转为json字符串
			String json=JSONObject.fromObject(jsonResult).toString();
			response.setContentType("text/html;charset=utf-8");
			response.getWriter().print(json);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

}
