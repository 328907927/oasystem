package com.hugo.servlet;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.hugo.biz.EmpBiz;
import com.hugo.biz.impl.EmpBizImpl;
import com.hugo.entity.Employee;

import comhugo.util.JSONResult;
import comhugo.util.StaticData;
import net.sf.json.JSONObject;

@WebServlet("/uploadHeadServlet")
@MultipartConfig
public class UploadHeadServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		//从请求对象中 获取出上传文件
		Part part =request.getPart("head");
		//文件包含的信息以二进制的形态的形态保存在一个输入流中
		InputStream is = part.getInputStream();
		//获取文件名称
		String contentDisposition=part.getHeader("content-disposition");
		String suffix =contentDisposition.substring(contentDisposition.lastIndexOf("."),contentDisposition.length()-1);
		//定义头像的合法文件后缀
		List<String> suffixs= new ArrayList<String>();
		suffixs.add(".jpg");
		suffixs.add(".jpn");
		suffixs.add(".gif");
		//判断数组的合法后缀 数组中是否包含本次上传的文件后缀
		if(suffixs.contains(suffix)){
			//获取服务器中保存上传文件的文件夹
		String root =request.getServletContext().getRealPath("/upload");
			//判断文件夹是否存在
			File file= new File(root);
			if(!file.exists()){
				//如果不存在就创建一个文件夹
				file.mkdirs();
			}
			//生成不会重复的文件名称
			String filename=UUID.randomUUID().toString().replace("-", "");
			//新建一个输出流对象 将用户上传的文件信息 保存到服务器的文件夹中
			FileOutputStream os=new FileOutputStream(root+"/"+filename+suffix);
			System.out.println(os);
			//新建一个缓存数据
			byte[] b= new byte[1024];
			int length=-1;
			while((length=is.read(b))>0){
				os.write(b,0,length);
			}
			os.flush();
			os.close();
			is.close();
			//更新当前员工在数据库中的头像地址信息
			EmpBiz biz = new EmpBizImpl();
			Employee emp = (Employee) request.getSession().getAttribute(StaticData.USER_INFO);
			try {
				biz.updateHead(emp.getEmpNo(), "upload/"+filename+suffix);
				JSONResult jsonResult =new JSONResult();
				jsonResult.setStatus(StaticData.SUCCESS);
				//将上传的图片地址 响应给客户端
				jsonResult.setMessage("upload/"+filename+suffix);
				//响应数据
				JSONObject json = JSONObject.fromObject(jsonResult);
				response.setContentType("text/html;charset=utf-8");
				response.getWriter().print(json.toString());
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}else{
			//响应信息给浏览器
			JSONResult jsonResult =new JSONResult();
			jsonResult.setStatus(StaticData.FAIL);
			jsonResult.setMessage(StaticData.FILE_TYPE_ERROR);
			//响应数据
			JSONObject json = JSONObject.fromObject(jsonResult);
			response.setContentType("text/html;charset=utf-8");
			response.getWriter().print(json.toString());
		}
	}

}
