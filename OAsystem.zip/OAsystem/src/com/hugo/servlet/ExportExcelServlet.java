package com.hugo.servlet;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;

import com.hugo.biz.EmpBiz;
import com.hugo.biz.impl.EmpBizImpl;


@WebServlet("/exportExcelServlet")
public class ExportExcelServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		EmpBiz biz =new EmpBizImpl();
		try {
			List<Map> list=biz.select();
			//创建一个excel工作
			HSSFWorkbook work=new HSSFWorkbook();
			//创建一个excel表格
			HSSFSheet sheet=work.createSheet("员工信息表");
			//设置表格每一个单元格的默认宽度
			sheet.setDefaultColumnWidth(20);
			//生成标题行
			HSSFRow row=sheet.createRow(0);
			//生成标题中的每一列
			HSSFCell idTitleCell=row.createCell(0);
			idTitleCell.setCellValue("员工编号");
			HSSFCell loginNameTitleCell=row.createCell(1);
			loginNameTitleCell.setCellValue("员工登录名");
			HSSFCell realNameTitleCell=row.createCell(2);
			realNameTitleCell.setCellValue("员工姓名");
			HSSFCell sexTitleCell=row.createCell(3);
			sexTitleCell.setCellValue("性别");
			HSSFCell deptNameTitleCell=row.createCell(4);
			deptNameTitleCell.setCellValue("部门名称");
			HSSFCell emailTitleCell=row.createCell(5);
			emailTitleCell.setCellValue("邮箱");
			//循环查询出的员工数据集合生成后续的所有行
			for(int i=0;i<list.size();i++){
				HSSFRow dataRow=sheet.createRow(i+1);
				//从集合的每一个键值对中获取出员工每一个属性添加到单元格中
				HSSFCell idCell=dataRow.createCell(0);
				idCell.setCellValue(list.get(i).get("empNo").toString());
				HSSFCell loginnameCell=dataRow.createCell(1);
				loginnameCell.setCellValue(list.get(i).get("loginName").toString());
				HSSFCell realnameCell=dataRow.createCell(2);
				realnameCell.setCellValue(list.get(i).get("realName").toString());
				HSSFCell sexCell=dataRow.createCell(3);
				sexCell.setCellValue(list.get(i).get("sex").toString());
				HSSFCell deptnameCell=dataRow.createCell(4);
				deptnameCell.setCellValue(list.get(i).get("deptName").toString());
				HSSFCell emailCell=dataRow.createCell(5);
				emailCell.setCellValue(list.get(i).get("email").toString());
			}
			//表格创建完成
			//设置下载文件头信息
			response.setContentType("application/octet-stream");
			String file=new String("员工信息表.xls".getBytes("utf-8"),"ISO8859-1");
			//设置多媒体下载的信息
			response.addHeader("Content-Disposition", "attachment;filename="+file);
			//使用excel工作对象帮我们响应excel表格文件
			work.write(response.getOutputStream());
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


}
