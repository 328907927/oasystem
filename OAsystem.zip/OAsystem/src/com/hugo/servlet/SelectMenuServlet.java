package com.hugo.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hugo.biz.MenuBiz;
import com.hugo.biz.impl.MenuBizImpl;
import com.hugo.entity.Employee;
import com.hugo.entity.Menu;

import comhugo.util.JSONResult;
import comhugo.util.StaticData;
import net.sf.json.JSONObject;

@WebServlet("/selectMenuServlet")
public class SelectMenuServlet extends HttpServlet {

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		Employee emp =(Employee) request.getSession().getAttribute(StaticData.USER_INFO);
		MenuBiz biz=new MenuBizImpl();
		try {
			List <Menu> menus =biz.selectByEmpNo(emp.getEmpNo());
			//封装json数据
			JSONResult jsonResult = new JSONResult();
			jsonResult.setLoginStatus(StaticData.LOGIN);
			jsonResult.setStatus(StaticData.SUCCESS);
			jsonResult.setList(menus);
			//使用json包提供的方法
			String json = JSONObject.fromObject(jsonResult).toString();
			response.setContentType("text/html;charset=utf-8");
			response.getWriter().print(json);
		} catch (Exception e) {

			e.printStackTrace();
		}
		
	}

}
