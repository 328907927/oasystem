package com.hugo.filter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hugo.biz.UserBiz;
import com.hugo.biz.impl.UserBizImpl;
import com.hugo.entity.Employee;

import comhugo.util.JSONResult;
import comhugo.util.StaticData;
import net.sf.json.JSONObject;

public class LoginCheckFilter implements Filter {
//定义放行的前缀和后缀的集合
	private List<String> prefixs = new ArrayList<String>();
	private List<String> suffixs = new ArrayList<String>();
	@Override
	public void destroy() {
		
	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain)
			throws IOException, ServletException {
		
//		当有请求满足filter的地址映射条件时，doFilter就会执行
//		第一个和第二个参数是请求和响应对象
//		第三个是一个filter链对象
//		fiter对象记录下一个filter获取是目标资源地址的地址映射
//		通过chain对象可让请求继续向下执行
//		System.out.println("请求进入filter");

//		将ServletRequest和ServletResponse强转为子类HttpServletRequest和HttpServletResponse
		HttpServletRequest request = (HttpServletRequest)req;
		HttpServletResponse response =(HttpServletResponse)resp;
//		统一处理request乱码，后续的servlet接受数据可以不再做乱码处理
		request.setCharacterEncoding("utf-8");
//		从请求对象中获取当前路径
		String uri =request.getRequestURI();
//		获取整个请求资源的地址
//		先找到整个资源地址中的斜杠下标		
		int index = uri.lastIndexOf("/");
		uri.substring(index);
		String resourceURI=uri.substring(index+1);
//		通过.来拆分资源地址
//		.是特殊字符必须使用\\转义
		String[] resources = resourceURI.split("\\.");
//		判断拆分出的数组长度，获取请求的前缀和后缀
		String  prefix = null;
		String suffix =null;
		if(resources.length<2){
		prefix =resourceURI;
			
		}else{
			prefix = resources[0];
//			数据的最后一个元素就是请求的后缀
			suffix = resources[resources.length-1];
		}
		if(prefixs.contains(prefix)||suffixs.contains(suffix)){
			
//			请求继续
			chain.doFilter(req, resp);
		}else{
//			作登录验证
//			从当前请求的cookie中获取token令牌信息
			Cookie[] cookies =request.getCookies();
//			定义token变量
			String token = null;
			if(cookies!=null){
					for(Cookie cookie:cookies){
						if(cookie.getName().equals("token")){
							token =cookie.getValue();
							break;
					}
					
				}
			}
//			判断token令牌
			if(token==null){
//				没有登录不能继续向下执行，直接响应信息
				responseINFO(request,response);
			}else{
//				使用token从数据库中查询用户信息，如果能查到说明，改浏览器是最后登录位置可以放行，否则不行
//				创建用户业务层对象
				UserBiz userBiz = new UserBizImpl();
				try {
					Employee employee = userBiz.selectByToken(token);
					if(employee==null){
//						根据token没有查询到用户 不能向下执行 直接响应信息
						responseINFO(request,response);
					}else{
//						请求继续执行下去
//						employee再次记录到session中，因为cookie跟session的生命周期不同步，没机会把数据往session中存
						request.getSession().setAttribute(StaticData.USER_INFO,employee);
//						请求继续
						chain.doFilter(req, resp);
						
					}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			
			
			
		}
		

	}
	public void responseINFO(HttpServletRequest request,HttpServletResponse response)throws IOException{
//			判断当前的请求是 普通请求还是Ajax请求
//		通过http的请求头信息的判断
		String requestType =request.getHeader("X-Request-with");
		if("XMLHttpRequest".equals(requestType)){
			JSONResult jsonResult =new JSONResult();
			jsonResult.setLoginStatus(StaticData.NOT_LOGIN);
			jsonResult.setMessage(StaticData.NOT_LOGIN_MESSAGE);
			response.setContentType("text/html;charset=utf-8");
//			将json转成字符串
			String json =JSONObject.fromObject(jsonResult).toString();
			response.getWriter().print(json);
			
		}else{
			response.sendRedirect("login.jsp");
			
		}
		
	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
//		添加放行的前缀地址
		prefixs.add("login");
//		添加放行的后缀
		suffixs.add("js");
		suffixs.add("css");
		suffixs.add("jpg");
		suffixs.add("png");
		suffixs.add("gif");
		suffixs.add("eot");
		suffixs.add("ttf");
		suffixs.add("woff");
		suffixs.add("woff2");
		suffixs.add("otf");
	}

}
