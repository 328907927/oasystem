package com.hugo.filter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.hugo.biz.MenuBiz;
import com.hugo.biz.impl.MenuBizImpl;
import com.hugo.entity.Employee;
import com.hugo.entity.Menu;

import comhugo.util.JSONResult;
import comhugo.util.StaticData;
import net.sf.json.JSONObject;

public class PrivilegeCheckFilter implements Filter{
	//定义放行的前缀和后缀的集合
		private List<String> prefixs = new ArrayList<String>();
		private List<String> suffixs = new ArrayList<String>();

	@Override
	public void destroy() {
		
	}

	@Override
	public void doFilter(ServletRequest req, ServletResponse resp, FilterChain chain)
			throws IOException, ServletException {
//		将ServletRequest和ServletResponse强转为子类HttpServletRequest和HttpServletResponse
		HttpServletRequest request = (HttpServletRequest)req;
		HttpServletResponse response =(HttpServletResponse)resp;
//		从请求对象中获取当前路径
		String uri =request.getRequestURI();
//		获取整个请求资源的地址
//		先找到整个资源地址中的斜杠下标		
		int index = uri.lastIndexOf("/");
		uri.substring(index);
		String resourceURI=uri.substring(index+1);
//		通过.来拆分资源地址
//		.是特殊字符必须使用\\转义
		String[] resources = resourceURI.split("\\.");
//		判断拆分出的数组长度，获取请求的前缀和后缀
		String  prefix = null;
		String suffix =null;
		if(resources.length<2){
		prefix =resourceURI;
			
		}else{
			prefix = resources[0];
//			数据的最后一个元素就是请求的后缀
			suffix = resources[resources.length-1];
		}
		if(prefixs.contains(prefix)||suffixs.contains(suffix)){
			
//			请求继续
			chain.doFilter(req, resp);
		}else{
//			查询出当前用户的菜单
			MenuBiz biz = new MenuBizImpl();
			Employee emp = (Employee) request.getSession().getAttribute(StaticData.USER_INFO);
			
			try {
			List<Menu> menus=biz.selectPrivilegeByEmpNo(emp.getEmpNo());
			boolean  b = false;
			for(Menu menu:menus){
				if(menu.getParentNo()!=0&&menu.getUrl().equals(resourceURI)){
					b=true;
					break;
				}
			}
			if(b){
				chain.doFilter(request, response);
				
			}else{
				responseINFO(request,response);
			}
			
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				
			}
			
		}
					
				
			
	}
	public void responseINFO(HttpServletRequest request,HttpServletResponse response)throws IOException{
//		判断当前的请求是 普通请求还是Ajax请求
//	通过http的请求头信息的判断
	String requestType =request.getHeader("X-Request-with");
	if("XMLHttpRequest".equals(requestType)){
		JSONResult jsonResult =new JSONResult();
		jsonResult.setLoginStatus(StaticData.NOT_HAS_PIVILEGE);
		jsonResult.setMessage(StaticData.NOT_HAS_PIVILEGE_MESSAGE);
		response.setContentType("text/html;charset=utf-8");
//		将json转成字符串
		String json =JSONObject.fromObject(jsonResult).toString();
		response.getWriter().print(json);
		
	}else{
		response.sendRedirect("index.jsp");
		
	}
	
}

	@Override
	public void init(FilterConfig arg0) throws ServletException {
//		添加放行的前缀地址
		prefixs.add("login");
		prefixs.add("index");
		prefixs.add("selectMenuServlet");
//		添加放行的后缀
		suffixs.add("js");
		suffixs.add("css");
		suffixs.add("jpg");
		suffixs.add("png");
		suffixs.add("gif");
		suffixs.add("eot");
		suffixs.add("ttf");
		suffixs.add("woff");
		suffixs.add("woff2");
		suffixs.add("otf");
		
	}

}
