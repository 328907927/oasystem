package com.hugo.dao;

import java.util.List;

import com.hugo.entity.Role;

public interface RoleDao {
	public List<Role> selectRole() throws Exception;
}
