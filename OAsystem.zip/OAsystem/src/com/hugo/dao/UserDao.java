package com.hugo.dao;

import com.hugo.entity.Employee;

public interface UserDao {
	public Employee selectByUsernameAndPassword(String username,String password)throws Exception;
	public void updateToken(int empNo,String token)throws Exception;
	public Employee  selectByToken(String token) throws Exception;
	
}
