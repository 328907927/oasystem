package com.hugo.dao;

import java.util.List;

import com.hugo.entity.Menu;

public interface MenuDao {
	public List<Menu> selectByEmpNo(int empNo) throws Exception;
	public List<Menu> selectPrivilegeByEmpNo(int empNo) throws Exception;
	public List<Menu> selectMenuByRoleNo( int roleNo) throws Exception;
	public List<Menu> selectMenuByParentNo(int parentNo)throws Exception;
}
