package com.hugo.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.hugo.dao.UserDao;
import com.hugo.entity.Employee;

public class UserDaoImpl extends BaseDao implements UserDao {

	@Override
	public Employee selectByUsernameAndPassword(String username, String password) 
			throws Exception {
		Connection conn= openConnection();
		PreparedStatement ps = conn.prepareStatement("select * from emp where loginname=? and password=?");
		ps.setString(1,username);
		ps.setString(2, password);
		ResultSet rs = ps.executeQuery();
		Employee employee = null;
		if(rs.next()){
			employee = new Employee();
			employee.setDeptNo(rs.getInt("deptno"));
			employee.setRealName(rs.getString("realname"));
			employee.setEamil(rs.getString("email"));
			employee.setEmpNo(rs.getInt("empno"));
			employee.setLoginName(username);
			employee.setSex(rs.getString("sex"));
			employee.setToken(rs.getString("token"));
			employee.setHead(rs.getString("head"));
			
		}
		rs.close();
		ps.close();
		conn.close();
		
		return employee;
		
		
	}

	@Override
	public void updateToken(int empNo, String token) throws Exception {
		// TODO Auto-generated method stub
		Connection conn= openConnection();
		PreparedStatement ps = conn.prepareStatement("update emp set token=? where empno=?");
		ps.setString(1,token);
		ps.setInt(2,empNo);
		ps.executeUpdate();
		
		ps.close();
		conn.close();
	}

	@Override
	public Employee selectByToken(String token) throws Exception {
		Connection conn= openConnection();
		PreparedStatement ps = conn.prepareStatement("select * from emp where token=?");
		ps.setString(1,token);
		ResultSet rs = ps.executeQuery();
		Employee employee = null;
		if(rs.next()){
			employee = new Employee();
			employee.setDeptNo(rs.getInt("deptno"));
			employee.setRealName(rs.getString("realname"));
			employee.setEamil(rs.getString("email"));
			employee.setEmpNo(rs.getInt("empno"));
			employee.setLoginName(rs.getString("loginname"));
			employee.setSex(rs.getString("sex"));
			employee.setToken(rs.getString("token"));
			employee.setHead(rs.getString("head"));
			
		}
		rs.close();
		ps.close();
		conn.close();
		
		return employee;
	}

	
		
		
		
		
		
	

}
