package com.hugo.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.hugo.dao.DeptDao;
import com.hugo.entity.Dept;

public class DeptDaoImpl extends BaseDao implements DeptDao {

	@Override
	public List<Dept> selectAllDept() throws Exception {
		Connection conn = openConnection();
		PreparedStatement ps =conn.prepareStatement("select * from dept where isdelete=0");
		ResultSet rs = ps.executeQuery(); 
		List<Dept> list = new ArrayList<Dept>();
		while(rs.next()){
			Dept dept = new Dept();
			dept.setDeptName(rs.getString("deptname"));
			dept.setDeptNo(rs.getInt("deptno"));
			
			list.add(dept);
			
			
		}
		rs.close();
		ps.close();
		conn.close();
		return list;
	}

	@Override
	public void insertDept(String deptName) throws Exception {
		Connection conn = openConnection();
		PreparedStatement ps =conn.prepareStatement("insert into dept values(null,?,0)");
		ps.setString(1,deptName);
		ps.executeUpdate(); 
		ps.close();
		conn.close();
	
		
	}

	@Override
	public void updateDept(int deptNo, String deptName) throws Exception {
		Connection conn = openConnection();
		PreparedStatement ps =conn.prepareStatement("update dept set deptname=? where deptno=?");
		ps.setString(1,deptName);
		ps.setInt(2,deptNo);
		ps.executeUpdate(); 
		ps.close();
		conn.close();
		
	}

	@Override
	public void updateDeptInsDelete(int deptNo) throws Exception {
		Connection conn = openConnection();
		PreparedStatement ps =conn.prepareStatement("update dept set isdelete=1 where deptno=?");
		ps.setInt(1,deptNo);
		ps.executeUpdate(); 
		ps.close();
		conn.close();
		
	}

}
