package com.hugo.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.hugo.dao.EmpDao;

public class EmpDaoImpl extends BaseDao implements EmpDao{

	@Override
	public List<Map> selectPage(int pageIndex,int num,int deptNo ,String realName) throws Exception {
		Connection conn= openConnection();
		//根据传过过来的数据动态组装成一个sql语句
		StringBuffer sql = new StringBuffer("select e.*,d.deptname from emp e inner join dept d on e.deptno=d.deptno where e.isdelete=0");
		//定义一个集合保存需要查询的条件数据
		List example = new ArrayList();
		// 依此判断部门编号和员工名称参数、
		if(deptNo!=0){
			//需要判断部门
			//追加判断部门条件
			sql.append(" and e.deptno=?");
			//将部门编号保存在集合中
			example.add(deptNo);
		}
		if(!"".equals(realName)){
			//需要判断用户名称
			//追加判断用户名称的条件
			sql.append(" and e.realname=?");
			//将用户名称编号保存到集合中
			example.add(realName);
		}
		//追加分页查询语句
		sql.append(" limit ?,?");
		//向集合中保存分页语句所需要的两个参数
		example.add((pageIndex-1)*num);
		example.add(num);
		//创建查询对象
		PreparedStatement ps = conn.prepareStatement(sql.toString());
		//由于查询语句中查询条件个数未知，需要从集合中循环给?赋值
			for(int i=0;i<example.size();i++){
				ps.setObject(i+1,example.get(i));
			}
			//执行查询
			ResultSet rs =ps.executeQuery();
			//循环每一行数据 将每一行数据保存在一个键值对中
			List<Map> list = new ArrayList<Map>();
			while(rs.next()){
				Map  map =new HashMap();
				//向键值对中
				map.put("empNo",rs.getInt("empno"));
				map.put("loginName",rs.getString("loginname"));
				map.put("realName",rs.getString("realname"));
				map.put("sex",rs.getString("sex"));
				map.put("deptName",rs.getString("deptName"));
				map.put("email",rs.getString("email"));
				
				//再将键值对保存到集合中
				list.add(map);
				
				
			}
			
			
			
		rs.close();
		ps.close();
		conn.close();
		return list;
	}

	@Override
	public int seletDataCount(int deptNo, String realName) throws Exception {
		Connection conn= openConnection();
		//根据传过过来的数据动态组装成一个sql语句
				StringBuffer sql = new StringBuffer("select count(1) from emp e inner join dept d on e.deptno=d.deptno where e.isdelete=0");
				//定义一个集合保存需要查询的条件数据
				List example = new ArrayList();
				// 依此判断部门编号和员工名称参数、
				if(deptNo!=0){
					//需要判断部门
					//追加判断部门条件
					sql.append(" and e.deptno=?");
					//将部门编号保存在集合中
					example.add(deptNo);
				}
				if(!"".equals(realName)){
					//需要判断用户名称
					//追加判断用户名称的条件
					sql.append(" and e.realname=?");
					//将用户名称编号保存到集合中
					example.add(realName);
					//创建查询对象
				}
					PreparedStatement ps = conn.prepareStatement(sql.toString());
					//由于查询语句中查询条件个数未知，需要从集合中循环给?赋值
						for(int i=0;i<example.size();i++){
							ps.setObject(i+1,example.get(i));
						}
						//执行查询
						ResultSet rs =ps.executeQuery();
						int count= 0;
						if(rs.next()){
							count =rs.getInt(1);
						}
						rs.close();
						ps.close();
						conn.close();
						return count;
				
				
				
	}

	@Override
	public void updateHead(int empNo, String src) throws Exception {
				Connection conn= openConnection();
				PreparedStatement ps = conn.prepareStatement("update emp set head=? where empno=?");
				ps.setString(1,src);
				ps.setInt(2,empNo);
				ps.executeUpdate();
				
				ps.close();
				conn.close();
		
	}

	@Override
	public List<Map> select() throws Exception {
		Connection conn= openConnection();
		String sql =  "select e.*,d.deptname from emp e inner join dept d on e.deptno=d.deptno where e.isdelete=0";
		PreparedStatement ps = conn.prepareStatement(sql.toString());
			//执行查询
			ResultSet rs =ps.executeQuery();
			//循环每一行数据 将每一行数据保存在一个键值对中
			List<Map> list = new ArrayList<Map>();
			while(rs.next()){
				Map  map =new HashMap();
				//向键值对中
				map.put("empNo",rs.getInt("empno"));
				map.put("loginName",rs.getString("loginname"));
				map.put("realName",rs.getString("realname"));
				map.put("sex",rs.getString("sex"));
				map.put("deptName",rs.getString("deptName"));
				map.put("email",rs.getString("email"));
				
				//再将键值对保存到集合中
				list.add(map);
							
			}
			return list;
  }
}

