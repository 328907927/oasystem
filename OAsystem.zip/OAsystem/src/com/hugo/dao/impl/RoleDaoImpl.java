package com.hugo.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.hugo.dao.RoleDao;
import com.hugo.entity.Role;

public class RoleDaoImpl extends BaseDao implements RoleDao{

	@Override
	public List<Role> selectRole() throws Exception {
		Connection conn = openConnection();
		PreparedStatement ps = conn.prepareStatement("select * from role");
		ResultSet rs = ps.executeQuery();
		List<Role> list =  new ArrayList<Role>();
		while(rs.next()){
			Role role = new Role();
			role.setRoleNo(rs.getInt("roleno"));
			role.setRoleName(rs.getString("rolename"));
			role.setRoleDesc(rs.getString("roledesc"));
			list.add(role);
		}
		rs.close();
		ps.close();
		conn.close();
		
		return list;
	}

}
