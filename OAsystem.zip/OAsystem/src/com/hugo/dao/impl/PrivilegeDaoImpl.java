package com.hugo.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import com.hugo.dao.PrivilegeDao;


public class PrivilegeDaoImpl extends BaseDao implements PrivilegeDao {

	@Override
	public void deletePrivilege(int roleNo) throws Exception {
		Connection conn = openConnection();
		PreparedStatement ps = conn.prepareStatement("delete from privilege where roleno=?");
		ps.setInt(1, roleNo);
		ps.executeUpdate();	
		ps.close();
		conn.close();
			
	}

	@Override
	public void insert(int roleNo, int menuNo) throws Exception {
		Connection conn = openConnection();
		PreparedStatement ps = conn.prepareStatement("insert into privilege values(null,?,?)");
		ps.setInt(1, roleNo);
		ps.setInt(2, menuNo);
		ps.executeUpdate();	
		ps.close();
		conn.close();
	}

}
