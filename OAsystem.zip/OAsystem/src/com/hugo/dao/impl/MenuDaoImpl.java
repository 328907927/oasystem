package com.hugo.dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.hugo.dao.MenuDao;
import com.hugo.entity.Menu;

public class MenuDaoImpl  extends BaseDao implements MenuDao{

	@Override
	public List<Menu> selectByEmpNo(int empNo) throws Exception {
			Connection conn = openConnection();
			PreparedStatement ps =conn.prepareStatement("select DISTINCT(m.menuno),m.menuname,m.parentno,m.url from emp e inner join emprole er on e.empno=er.empno inner join privilege pri on er.roleno=pri.roleno inner join menu m on pri.menuno=m.menuno where e.empno=? and m.type=0");
			ps.setInt(1,empNo);
			ResultSet rs = ps.executeQuery();
			List<Menu> menus = new ArrayList<Menu>();
			while(rs.next()){
				Menu menu =new Menu();
				menu.setMenuNo(rs.getInt("menuno"));
				menu.setMenuName(rs.getString("menuName"));
				menu.setParentNo(rs.getInt("parentno"));
				menu.setUrl(rs.getString("url"));
				menus.add(menu);
			}
			
			rs.close();
			ps.close();
			conn.close();
			
			
			return menus;
	}

	@Override
	public List<Menu> selectPrivilegeByEmpNo(int empNo) throws Exception {
		Connection conn = openConnection();
		PreparedStatement ps =conn.prepareStatement("select DISTINCT(m.menuno),m.menuname,m.parentno,m.url from emp e inner join emprole er on e.empno=er.empno inner join privilege pri on er.roleno=pri.roleno inner join menu m on pri.menuno=m.menuno where e.empno=?");
		ps.setInt(1,empNo);
		ResultSet rs = ps.executeQuery();
		List<Menu> menus = new ArrayList<Menu>();
		while(rs.next()){
			Menu menu =new Menu();
			menu.setMenuNo(rs.getInt("menuno"));
			menu.setMenuName(rs.getString("menuName"));
			menu.setParentNo(rs.getInt("parentno"));
			menu.setUrl(rs.getString("url"));
			menus.add(menu);
		}
		
		rs.close();
		ps.close();
		conn.close();
		
		
		return menus;

	}
//根据角色编号查询拥有的菜单
	@Override
	public List<Menu> selectMenuByRoleNo(int roleNo) throws Exception {
		Connection conn = openConnection();
		PreparedStatement ps =conn.prepareStatement("select m.* from menu m inner join privilege p on p.menuno=m.menuno where p.roleno=?");
		ps.setInt(1,roleNo);
		ResultSet rs = ps.executeQuery();
		List<Menu> menus = new ArrayList<Menu>();
		while(rs.next()){
			Menu menu =new Menu();
			menu.setMenuNo(rs.getInt("menuno"));
			menu.setMenuName(rs.getString("menuName"));
			menu.setParentNo(rs.getInt("parentno"));
			menu.setUrl(rs.getString("url"));
			menus.add(menu);
		}
		
		rs.close();
		ps.close();
		conn.close();
		
		
		return menus;
	}

	@Override
	public List<Menu> selectMenuByParentNo(int parentNo) throws Exception {
		Connection conn = openConnection();
		PreparedStatement ps =conn.prepareStatement("select * from menu where parentNo=?");
		ps.setInt(1,parentNo);
		ResultSet rs = ps.executeQuery();
		List<Menu> menus = new ArrayList<Menu>();
		while(rs.next()){
			Menu menu =new Menu();
			menu.setMenuNo(rs.getInt("menuno"));
			menu.setMenuName(rs.getString("menuName"));
			menu.setParentNo(rs.getInt("parentno"));
			menu.setUrl(rs.getString("url"));
			menus.add(menu);
		}
		
		rs.close();
		ps.close();
		conn.close();
		
		
		return menus;
	}
	
}
