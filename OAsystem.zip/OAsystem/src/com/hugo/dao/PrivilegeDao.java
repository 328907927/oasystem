package com.hugo.dao;

public interface PrivilegeDao{
	public void deletePrivilege(int roleNo) throws Exception;
	public void insert(int roleNo,int menuNo) throws Exception;
}
