package com.hugo.biz.impl;

import java.util.List;

import com.hugo.biz.MenuBiz;
import com.hugo.dao.MenuDao;
import com.hugo.dao.impl.MenuDaoImpl;
import com.hugo.entity.Menu;

public class MenuBizImpl implements MenuBiz {
	private MenuDao menu= new MenuDaoImpl();
	
	@Override
	public List<Menu> selectByEmpNo(int empNo) throws Exception {
		
		return menu.selectByEmpNo(empNo);
	}

	@Override
	public List<Menu> selectPrivilegeByEmpNo(int empNo) throws Exception {
		// TODO Auto-generated method stub
		return menu.selectPrivilegeByEmpNo(empNo);
	}

	@Override
	public List<Menu> selectMenuByRoleNo(int roleNo) throws Exception {
		// TODO Auto-generated method stub
		return menu.selectMenuByRoleNo(roleNo);
	}

}
