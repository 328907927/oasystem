package com.hugo.biz.impl;

import java.util.List;

import com.hugo.biz.RoleBiz;
import com.hugo.dao.RoleDao;
import com.hugo.dao.impl.RoleDaoImpl;
import com.hugo.entity.Role;

public class RoleBizImpl implements RoleBiz{
	private  RoleDao dao = new RoleDaoImpl();
	@Override
	public List<Role> selectRole() throws Exception {

		return dao.selectRole();
	}

}
