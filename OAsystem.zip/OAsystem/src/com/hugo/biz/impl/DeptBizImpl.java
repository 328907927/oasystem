package com.hugo.biz.impl;

import java.util.List;

import com.hugo.biz.DeptBiz;
import com.hugo.dao.DeptDao;
import com.hugo.dao.impl.DeptDaoImpl;
import com.hugo.entity.Dept;

public class DeptBizImpl implements DeptBiz{
	private DeptDao deptDao = new DeptDaoImpl();
	@Override
	public List<Dept> selectAllDept() throws Exception {
		return deptDao.selectAllDept();
	}
	@Override
	public void insertDept(String deptName) throws Exception {
		deptDao.insertDept(deptName);
	}
	@Override
	public void updateDept(int deptNo, String deptName) throws Exception {
		deptDao.updateDept(deptNo,deptName);
	}
	@Override
	public void delete(int deptNo) throws Exception {
		deptDao.updateDeptInsDelete(deptNo);
	}

}
