package com.hugo.biz.impl;

import com.hugo.biz.UserBiz;
import com.hugo.dao.UserDao;
import com.hugo.dao.impl.UserDaoImpl;
import com.hugo.entity.Employee;

public class UserBizImpl implements UserBiz{
	//创建数据层接口对应的实现类
	private  UserDao userDao = new UserDaoImpl();
	@Override
	public Employee login(String username, String password) throws Exception {
		return userDao.selectByUsernameAndPassword(username, password);
	}
	@Override
	public void setToken(int empNo, String token) throws Exception {
		userDao.updateToken(empNo, token);
	}
	@Override
	public Employee selectByToken(String token) throws Exception {

		return userDao.selectByToken(token);
	}
	

}
