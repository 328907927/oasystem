package com.hugo.biz.impl;

import java.util.List;
import java.util.Map;

import com.hugo.biz.EmpBiz;
import com.hugo.dao.EmpDao;
import com.hugo.dao.impl.EmpDaoImpl;

public class EmpBizImpl implements EmpBiz{
	private EmpDao  dao = new EmpDaoImpl();
	
	@Override
	public List<Map> selectPage(int pageIndex,int num,int deptNo ,String realName) throws Exception {
		
		return dao.selectPage(pageIndex, num, deptNo, realName);
	}

	@Override
	public int seletDataCount(int deptNo, String realName) throws Exception {
		
		return dao.seletDataCount(deptNo, realName);
		
	}

	@Override
	public void updateHead(int empNo, String src) throws Exception {
			dao.updateHead(empNo, src);
	}

	@Override
	public List<Map> select() throws Exception {
		// TODO Auto-generated method stub
		return dao.select();
	}

}
