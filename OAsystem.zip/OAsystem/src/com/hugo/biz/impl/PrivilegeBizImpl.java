package com.hugo.biz.impl;

import java.util.List;

import com.hugo.biz.PrivilegeBiz;
import com.hugo.dao.MenuDao;
import com.hugo.dao.PrivilegeDao;
import com.hugo.dao.impl.MenuDaoImpl;
import com.hugo.dao.impl.PrivilegeDaoImpl;
import com.hugo.entity.Menu;

public class PrivilegeBizImpl implements PrivilegeBiz{
private PrivilegeDao dao = new PrivilegeDaoImpl();
private MenuDao menuDao = new MenuDaoImpl();
	@Override
	public void sharPrivilege(int roleNo, String[] pnos, String[] cnos) throws Exception {

		//1.删除当前角色所有权限
		dao. deletePrivilege(roleNo);
		//2.新增所有父级菜单权限
		if(pnos!=null&&pnos.length>0){
			for(String pno:pnos){
				dao.insert(roleNo, Integer.parseInt(pno));
			}
		}
	
		//3.新增所有的子级菜单下的数据菜单
		if(cnos!=null&&cnos.length>0){
			for(String cno:cnos){
				dao.insert(roleNo, Integer.parseInt(cno));
			}	
		}
		
		//4.查询子级菜单下的数据并新增
		for(String cno:cnos){
		List<Menu> list = menuDao.selectMenuByParentNo(Integer.parseInt(cno));
			for(Menu menu:list){
				dao.insert(roleNo,menu.getMenuNo());
			}
		}
	}

}
