package com.hugo.biz;

import java.util.List;

import com.hugo.entity.Dept;

public interface DeptBiz {
	public List<Dept>selectAllDept() throws Exception;
	public void insertDept(String deptName)throws Exception;
	public void updateDept(int deptNo,String deptName)throws Exception;
	public void delete(int deptNo)throws Exception;
}
