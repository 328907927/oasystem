package com.hugo.biz;

import com.hugo.entity.Employee;

public interface UserBiz {
	public Employee login(String username,String password)throws Exception;
	
	public void setToken(int empNo, String token) throws Exception;
	public Employee  selectByToken(String token) throws Exception;
}
