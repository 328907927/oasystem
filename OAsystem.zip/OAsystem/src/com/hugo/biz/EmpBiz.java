package com.hugo.biz;

import java.util.List;
import java.util.Map;

public interface EmpBiz {
	public List<Map> selectPage(int pageIndex,int num,int deptNo ,String realName) throws Exception;
	public int seletDataCount(int deptNo,String realName) throws Exception;
	public void updateHead(int empNo,String src)throws Exception;
	public List<Map> select() throws Exception;
}

