package com.hugo.biz;

public interface PrivilegeBiz {

	public void sharPrivilege(int roleNo,String[] pnos,String[] cnos) throws Exception;


}
