package com.hugo.biz;

import java.util.List;

import com.hugo.entity.Role;

public interface RoleBiz {
	public List<Role> selectRole() throws Exception;
}
