package comhugo.util;

public class StaticData {
	public static final String USERNAME_NULL="用户名不能为空";
	public static final String PASSWORD_NULL="密码不能为空";
	public static final String USERNAME_OR_PASSWORD_ERROR="用户名或者密码错误";
	public static final String USER_INFO="user";
//	定义未登录和已登录的状态
	public static final int LOGIN=0;
	public static final int NOT_LOGIN=1;
	public static final String NOT_LOGIN_MESSAGE= "用户还未登录,或者账号在其他地方登录";
//	定义执行结果
	public static final String SUCCESS="success";
	public static final String FAIL="fail";
	public static final String ERROR="error";
//	定义一个没有权限的一个状态
	public static final int NOT_HAS_PIVILEGE= 0;
	public static final String NOT_HAS_PIVILEGE_MESSAGE= "没有权限执行此操作";
//	定义操作成功的提示语
	public static final String INSERT_DEPT_SUCCESS_MESSAGE="新增部门成功";
	public static final String INSERT_DEPT_FAIL_MESSAGE="新增部门失败";
	public static final String UPDATE_DEPT_SUCCESS_MESSAGE="更新部门成功";
	public static final String DELETE_DEPT_SUCCESS_MESSAGE="删除部门成功";
//	定义授权成功信息
	public static final String AUTHORIZATION__SUCCESS_MESSAGE="授权成功";
//定义上传的图片类型不匹配
	public static final String FILE_TYPE_ERROR="文件类型错误";
}
